/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     4/16/2023 10:16:05 PM                        */
/*==============================================================*/


drop table if exists AGENCIES;

drop table if exists BILLINGS;

drop table if exists BOOKINGS;

drop table if exists CLIENTS;

drop table if exists CONTRACTS;

drop table if exists CUSTOMER_INFLICTED_VEHICLE_DAMAGES;

drop table if exists DATES;

drop table if exists DISCOUNTS;

drop table if exists DRIVERS;

drop table if exists EMPLOYEES;

drop table if exists EQUIPMENT_CATEGORIES;

drop table if exists INSURANCE_PLANS;

drop table if exists INSURANCE_PLAN_CATEGORIES;

drop table if exists LOYALTY_CARDS;

drop table if exists LOYALTY_PROGRAM_TIERS;

drop table if exists PRICINGS;

drop table if exists RENTAL_BUSINESSES;

drop table if exists RENTAL_EXTRA_EQUIPMENT;

drop table if exists RENTAL_PACKAGES;

drop table if exists RENTING_EXTRA_EQUIPMENT;

drop table if exists VEHICLES;

drop table if exists VEHICLE_CATEGORIES;

/*==============================================================*/
/* Table: AGENCIES                                              */
/*==============================================================*/
create table AGENCIES
(
   AGENCY_ID            int not null,
   OWNED_BY_RENTAL_BUSINESS int not null,
   AGENCY_LOCATION      char(110),
   primary key (AGENCY_ID)
);

/*==============================================================*/
/* Table: BILLINGS                                              */
/*==============================================================*/
create table BILLINGS
(
   BILLING_ID           int not null,
   RENTAL_PACKAGE_COMPOSES int,
   BOOKINGS_COMPOSE     int,
   FOR_A_CONTRACT       int not null,
   PAYMENT_TYPE         varchar(55),
   primary key (BILLING_ID)
);

/*==============================================================*/
/* Table: BOOKINGS                                              */
/*==============================================================*/
create table BOOKINGS
(
   FOR_A_RENTAL_PACKAGE int not null,
   OF_A_CONTRACT        int not null,
   BOOKING_ID           int not null,
   CHOSEN_BY_CLIENT     int not null,
   OVERSEEN_BY_EMPLOYEE int,
   RENTED_DRIVER_SERVICES_FROM int,
   MADE_IN_AGENCY       int not null,
   DEPOSIT_AMOUNT       numeric(8,0),
   FULL_RENTAL_PACKAGE_PRICE decimal,
   primary key (FOR_A_RENTAL_PACKAGE, OF_A_CONTRACT, BOOKING_ID)
);

/*==============================================================*/
/* Table: CLIENTS                                               */
/*==============================================================*/
create table CLIENTS
(
   CLIENT_ID            int not null,
   CREDIT_CARD_NUMBER   numeric(19,0),
   CLIENT_EMAIL         varchar(55),
   CLIENT_NAME          char(55),
   CLIENT_SURNAME       char(55),
   primary key (CLIENT_ID)
);

/*==============================================================*/
/* Table: CONTRACTS                                             */
/*==============================================================*/
create table CONTRACTS
(
   CONTRACT_ID          int not null,
   CREATED_BY_EMPLOYEE  int,
   SIGNED_BY_CLIENT     int not null,
   FULL_SERVICE_PRICE   decimal,
   primary key (CONTRACT_ID)
);

/*==============================================================*/
/* Table: CUSTOMER_INFLICTED_VEHICLE_DAMAGES                    */
/*==============================================================*/
create table CUSTOMER_INFLICTED_VEHICLE_DAMAGES
(
   VEHICLE_DAMAGE_ID    int not null,
   CONNECTED_TO_VEHICLE_ON_RENTAL_PACKAGE int not null,
   BELONGS_TO_CONTRACT  int not null,
   CONNECTED_TO_BOOKING int not null,
   VEHICLE_DAMAGE_PRICE decimal,
   primary key (VEHICLE_DAMAGE_ID)
);

/*==============================================================*/
/* Table: DATES                                                 */
/*==============================================================*/
create table DATES
(
   DATE_ID              int not null,
   primary key (DATE_ID)
);

/*==============================================================*/
/* Table: DISCOUNTS                                             */
/*==============================================================*/
create table DISCOUNTS
(
   DISCOUNT_ID          int not null,
   primary key (DISCOUNT_ID)
);

/*==============================================================*/
/* Table: DRIVERS                                               */
/*==============================================================*/
create table DRIVERS
(
   EMPLOYEE_ID          int not null,
   DRIVER_ID            int not null,
   AGENCY_ID            int,
   EMPLOYEE_NAME        char(55),
   EMPLOYEE_SURNAME     char(55),
   BIRTH_DATE           date,
   DRIVING_PERMIT       varchar(15) not null,
   primary key (EMPLOYEE_ID, DRIVER_ID)
);

/*==============================================================*/
/* Table: EMPLOYEES                                             */
/*==============================================================*/
create table EMPLOYEES
(
   EMPLOYEE_ID          int not null,
   CAN_BE_A_DRIVER      int,
   WORKS_IN_AGENCY      int not null,
   EMPLOYEE_NAME        char(55),
   EMPLOYEE_SURNAME     char(55),
   BIRTH_DATE           date,
   primary key (EMPLOYEE_ID)
);

/*==============================================================*/
/* Table: EQUIPMENT_CATEGORIES                                  */
/*==============================================================*/
create table EQUIPMENT_CATEGORIES
(
   EQUIPMENT_CATEGORY_ID int not null,
   EQUIPMENT_CATEGORY_NAME varchar(55),
   primary key (EQUIPMENT_CATEGORY_ID)
);

/*==============================================================*/
/* Table: INSURANCE_PLANS                                       */
/*==============================================================*/
create table INSURANCE_PLANS
(
   INSURANCE_PLAN_ID    int not null,
   INSURANCE_PLAN_CATEGORY int not null,
   PURCHASED_WITH_RENTAL_PACKAGE int not null,
   INSURANCE_PLAN_PRICE decimal(0,0),
   primary key (INSURANCE_PLAN_ID)
);

/*==============================================================*/
/* Table: INSURANCE_PLAN_CATEGORIES                             */
/*==============================================================*/
create table INSURANCE_PLAN_CATEGORIES
(
   INSURANCE_PLAN_CATEGORY_ID int not null,
   INSURANCE_PLAN_CATEGORY_NAME varchar(55),
   primary key (INSURANCE_PLAN_CATEGORY_ID)
);

/*==============================================================*/
/* Table: LOYALTY_CARDS                                         */
/*==============================================================*/
create table LOYALTY_CARDS
(
   LOYALTY_CARD_ID      int not null,
   LOYALTY_PROGRAM_TIER int not null,
   BELONGS_TO_CLIENT    int not null,
   primary key (LOYALTY_CARD_ID)
);

/*==============================================================*/
/* Table: LOYALTY_PROGRAM_TIERS                                 */
/*==============================================================*/
create table LOYALTY_PROGRAM_TIERS
(
   LOYALTY_PROGRAM_ID   int not null,
   LOYALTY_PROGRAM_NAME varchar(55),
   primary key (LOYALTY_PROGRAM_ID)
);

/*==============================================================*/
/* Table: PRICINGS                                              */
/*==============================================================*/
create table PRICINGS
(
   VEHICLE_CATEGORY_ID  int not null,
   VEHICLE_ID           int not null,
   DATE_ID              int not null,
   PRICE_ID             int not null,
   RESERVED_BY_RENTAL_PACKAGE int,
   PRICE                decimal not null,
   CURRENCY             char(3) not null,
   primary key (VEHICLE_CATEGORY_ID, VEHICLE_ID, DATE_ID, PRICE_ID)
);

/*==============================================================*/
/* Table: RENTAL_BUSINESSES                                     */
/*==============================================================*/
create table RENTAL_BUSINESSES
(
   RENTAL_BUSINESS_ID   int not null,
   RENTAL_BUSINESS_NAME varchar(55),
   TAX_IDENTIFICATION_NUMBER numeric(9,0) not null,
   primary key (RENTAL_BUSINESS_ID)
);

/*==============================================================*/
/* Table: RENTAL_EXTRA_EQUIPMENT                                */
/*==============================================================*/
create table RENTAL_EXTRA_EQUIPMENT
(
   RENTAL_EXTRA_EQUIPMENT_ID int not null,
   IS_EQUIPMENT_CATEGORY_TYPE int not null,
   RENTAL_EQUIPMENT_NAME varchar(55),
   EQUIPMENT_PRICE      decimal,
   primary key (RENTAL_EXTRA_EQUIPMENT_ID)
);

/*==============================================================*/
/* Table: RENTAL_PACKAGES                                       */
/*==============================================================*/
create table RENTAL_PACKAGES
(
   RENTAL_PACKAGE_ID    int not null,
   PART_OF_CONTRACT     int,
   CALCULATES_BOOKING   int,
   CHOSEN_BY_CLIENT     int,
   DISCOUNT_CAN_TYPE_BE_APPLIED int,
   RENTED_EXTRA_EQUIPMENT int,
   OVERSEEN_BY_EMPLOYEE int,
   RENTED_DRIVER_SERVICES_FROM int,
   PURCHASED_INSURANCE_PLAN int,
   PICKUP_DATE          date,
   PICKUP_TIME          time,
   PICKUP_LOCATION      char(110),
   DROPOFF_DATE         date,
   DROPOFF_TIME         time,
   DROPOFF_LOCATION     char(110),
   primary key (RENTAL_PACKAGE_ID)
);

/*==============================================================*/
/* Table: RENTING_EXTRA_EQUIPMENT                               */
/*==============================================================*/
create table RENTING_EXTRA_EQUIPMENT
(
   CAN_BE_RENTED_BY     int not null,
   CAN_RENT             int not null,
   ARTICLE_RENTED_NUMBER_OF_TIMES int,
   primary key (CAN_BE_RENTED_BY, CAN_RENT)
);

/*==============================================================*/
/* Table: VEHICLES                                              */
/*==============================================================*/
create table VEHICLES
(
   BELONGS_TO_VEHICLE_CATEGORY int not null,
   VEHICLE_ID           int not null,
   VEHICLE_STATUS       char(55),
   primary key (BELONGS_TO_VEHICLE_CATEGORY, VEHICLE_ID)
);

/*==============================================================*/
/* Table: VEHICLE_CATEGORIES                                    */
/*==============================================================*/
create table VEHICLE_CATEGORIES
(
   VEHICLE_CATEGORY_ID  int not null,
   VEHICLE_CATEGORY_NAME char(55),
   primary key (VEHICLE_CATEGORY_ID)
);

alter table AGENCIES add constraint FK_BUSINESS_BRANCHES foreign key (OWNED_BY_RENTAL_BUSINESS)
      references RENTAL_BUSINESSES (RENTAL_BUSINESS_ID) on delete restrict on update restrict;

alter table BILLINGS add constraint FK_HAS foreign key (FOR_A_CONTRACT)
      references CONTRACTS (CONTRACT_ID) on delete restrict on update restrict;

alter table BILLINGS add constraint FK_RELATIONSHIP_9 foreign key (RENTAL_PACKAGE_COMPOSES, FOR_A_CONTRACT, BOOKINGS_COMPOSE)
      references BOOKINGS (FOR_A_RENTAL_PACKAGE, OF_A_CONTRACT, BOOKING_ID) on delete restrict on update restrict;

alter table BOOKINGS add constraint FK_BOOKING_AGENCY foreign key (MADE_IN_AGENCY)
      references AGENCIES (AGENCY_ID) on delete restrict on update restrict;

alter table BOOKINGS add constraint FK_CALCULATES_THE_DEPOSIT_AND_PRICE2 foreign key (FOR_A_RENTAL_PACKAGE)
      references RENTAL_PACKAGES (RENTAL_PACKAGE_ID) on delete restrict on update restrict;

alter table BOOKINGS add constraint FK_CAN_MAKE foreign key (CHOSEN_BY_CLIENT)
      references CLIENTS (CLIENT_ID) on delete restrict on update restrict;

alter table BOOKINGS add constraint FK_COMPOSES foreign key (OF_A_CONTRACT)
      references CONTRACTS (CONTRACT_ID) on delete restrict on update restrict;

alter table BOOKINGS add constraint FK_RELATIONSHIP_21 foreign key (OVERSEEN_BY_EMPLOYEE, RENTED_DRIVER_SERVICES_FROM)
      references DRIVERS (EMPLOYEE_ID, DRIVER_ID) on delete restrict on update restrict;

alter table CONTRACTS add constraint FK_CAN_HAVE foreign key (SIGNED_BY_CLIENT)
      references CLIENTS (CLIENT_ID) on delete restrict on update restrict;

alter table CONTRACTS add constraint FK_WORKS_ON foreign key (CREATED_BY_EMPLOYEE)
      references EMPLOYEES (EMPLOYEE_ID) on delete restrict on update restrict;

alter table CUSTOMER_INFLICTED_VEHICLE_DAMAGES add constraint FK_DAMAGE_CHARGE foreign key (CONNECTED_TO_VEHICLE_ON_RENTAL_PACKAGE, BELONGS_TO_CONTRACT, CONNECTED_TO_BOOKING)
      references BOOKINGS (FOR_A_RENTAL_PACKAGE, OF_A_CONTRACT, BOOKING_ID) on delete restrict on update restrict;

alter table DRIVERS add constraint FK_CAN_BE2 foreign key (EMPLOYEE_ID)
      references EMPLOYEES (EMPLOYEE_ID) on delete restrict on update restrict;

alter table DRIVERS add constraint FK_INHERITANCE_1 foreign key (EMPLOYEE_ID)
      references EMPLOYEES (EMPLOYEE_ID) on delete restrict on update restrict;

alter table EMPLOYEES add constraint FK_CAN_BE foreign key (CAN_BE_A_DRIVER, CAN_BE_A_DRIVER)
      references DRIVERS (EMPLOYEE_ID, DRIVER_ID) on delete restrict on update restrict;

alter table EMPLOYEES add constraint FK_WORKS_IN foreign key (WORKS_IN_AGENCY)
      references AGENCIES (AGENCY_ID) on delete restrict on update restrict;

alter table INSURANCE_PLANS add constraint FK_CAN_BE_BOUGHT foreign key (PURCHASED_WITH_RENTAL_PACKAGE)
      references RENTAL_PACKAGES (RENTAL_PACKAGE_ID) on delete restrict on update restrict;

alter table INSURANCE_PLANS add constraint FK_INSURANCE_TYPE foreign key (INSURANCE_PLAN_CATEGORY)
      references INSURANCE_PLAN_CATEGORIES (INSURANCE_PLAN_CATEGORY_ID) on delete restrict on update restrict;

alter table LOYALTY_CARDS add constraint FK_BELONGS_TO foreign key (BELONGS_TO_CLIENT)
      references CLIENTS (CLIENT_ID) on delete restrict on update restrict;

alter table LOYALTY_CARDS add constraint FK_LOYALTY_CARD_TIER foreign key (LOYALTY_PROGRAM_TIER)
      references LOYALTY_PROGRAM_TIERS (LOYALTY_PROGRAM_ID) on delete restrict on update restrict;

alter table PRICINGS add constraint FK_DETERMINES foreign key (RESERVED_BY_RENTAL_PACKAGE)
      references RENTAL_PACKAGES (RENTAL_PACKAGE_ID) on delete restrict on update restrict;

alter table PRICINGS add constraint FK_OF_A_VEHICLE foreign key (VEHICLE_CATEGORY_ID, VEHICLE_ID)
      references VEHICLES (BELONGS_TO_VEHICLE_CATEGORY, VEHICLE_ID) on delete restrict on update restrict;

alter table PRICINGS add constraint FK_ON_A_DATE foreign key (DATE_ID)
      references DATES (DATE_ID) on delete restrict on update restrict;

alter table RENTAL_EXTRA_EQUIPMENT add constraint FK_EQUIPMENT_TYPE foreign key (IS_EQUIPMENT_CATEGORY_TYPE)
      references EQUIPMENT_CATEGORIES (EQUIPMENT_CATEGORY_ID) on delete restrict on update restrict;

alter table RENTAL_PACKAGES add constraint FK_CALCULATES_THE_DEPOSIT_AND_PRICE foreign key (RENTAL_PACKAGE_ID, PART_OF_CONTRACT, CALCULATES_BOOKING)
      references BOOKINGS (FOR_A_RENTAL_PACKAGE, OF_A_CONTRACT, BOOKING_ID) on delete restrict on update restrict;

alter table RENTAL_PACKAGES add constraint FK_CAN_APPLY_TO foreign key (DISCOUNT_CAN_TYPE_BE_APPLIED)
      references DISCOUNTS (DISCOUNT_ID) on delete restrict on update restrict;

alter table RENTAL_PACKAGES add constraint FK_CAN_BE_ADDED foreign key (OVERSEEN_BY_EMPLOYEE, RENTED_DRIVER_SERVICES_FROM)
      references DRIVERS (EMPLOYEE_ID, DRIVER_ID) on delete restrict on update restrict;

alter table RENTAL_PACKAGES add constraint FK_CAN_BE_BOUGHT2 foreign key (PURCHASED_INSURANCE_PLAN)
      references INSURANCE_PLANS (INSURANCE_PLAN_ID) on delete restrict on update restrict;

alter table RENTAL_PACKAGES add constraint FK_CREATES foreign key (CHOSEN_BY_CLIENT)
      references CLIENTS (CLIENT_ID) on delete restrict on update restrict;

alter table RENTAL_PACKAGES add constraint FK_RELATIONSHIP_17 foreign key (RENTED_EXTRA_EQUIPMENT)
      references RENTAL_EXTRA_EQUIPMENT (RENTAL_EXTRA_EQUIPMENT_ID) on delete restrict on update restrict;

alter table RENTING_EXTRA_EQUIPMENT add constraint FK_CAN_BE_RENTED_BY foreign key (CAN_RENT)
      references RENTAL_EXTRA_EQUIPMENT (RENTAL_EXTRA_EQUIPMENT_ID) on delete restrict on update restrict;

alter table RENTING_EXTRA_EQUIPMENT add constraint FK_CAN_RENT foreign key (CAN_BE_RENTED_BY)
      references RENTAL_PACKAGES (RENTAL_PACKAGE_ID) on delete restrict on update restrict;

alter table VEHICLES add constraint FK_TYPE_OF_CAR foreign key (BELONGS_TO_VEHICLE_CATEGORY)
      references VEHICLE_CATEGORIES (VEHICLE_CATEGORY_ID) on delete restrict on update restrict;

